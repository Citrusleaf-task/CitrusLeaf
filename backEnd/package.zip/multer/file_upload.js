const multer = require("multer");

const fileStorage = multer.diskStorage({
    // path
    destination: (req, file, cb) => {
        cb(null, "file");
    },
    // file save detail
    filename: (req, file, callback) => {
        callback(null, file.originalname);
    }
});
// console.log(fileStorage.filename)
// console.log(fileStorage.destination)
const upload = multer({
    storage: fileStorage,
});




module.exports = upload;