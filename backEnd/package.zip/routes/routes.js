const express = require("express");

const routes = express.Router();
const {register,login} = require("../controller/authtication.controller")
const {singleUserTask,updateById,deleteTaskById,taskAdd} = require("../controller/userController")
// \
const multer = require("multer");
// const  upload = require("../multer/file_upload")

// const fileStorage = multer.diskStorage({
//     // path
//     destination: (req, file, cb) => {
//         cb(null, "./file");
//     },
//     // file save detail
//     filename: (req, file, callback) => {
//         callback(null, file.originalname);
//     }
// });
// // console.log(fileStorage.filename)
// // console.log(fileStorage.destination)
// const upload = multer({
//     storage: fileStorage,
// });

const upload = multer({
    Storage: multer.diskStorage({
        destination: function (req,file,cb){
            cb(null,"../multer/file/")
        },
        filename: function (req, res, cb){
            cb(null,file.filedname )
        }
        
    })
})



// routes.get("/user", all);
routes.post("/login", login);
routes.post("/register",register);
routes.post("/add-task",upload.single("attachment") ,taskAdd
)
routes.get("/user", singleUserTask);
routes.put("user", updateById);
routes.delete("user", deleteTaskById);

module.exports = { routes };
