const con = require('../model/db.connect')
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");


module.exports = {
  taskAdd: async (req, res) => {
    try {
      const token = req.header("token");

      await jwt.verify(token, process.env.JWT_TOKEN, (err, user) => {
        if (err) {
          return createError(401, "token is not verified")
        }
        // user detail which is present inside the token 
        req.user = user;
      });

      const attachment = req.file;
      console.log(attachment)
      let email = req.user.email;
      console.log(email)


      const { title, due_date } = req.body;
      const data = { title, due_date, attachment, email }
      console.log(data)
      const sqlQuery = "INSERT INTO task SET ?";
      await con.query(sqlQuery, data, (err, result) => {
        if (err) {
          return res.json({ Error: err.sqlMessage })
        }
        res.json({ status: 200, response: result })
      })

    } catch (err) {
      return res.json({ error: err.message })
    }
  },
  // all: async (req, res) => {
  //   try {
  //     const token = req.header("token");

  //     await jwt.verify(token, process.env.JWT_TOKEN, (err, user) => {
  //       if (err) {
  //         return createError(401, "token is not verified")
  //       }
  //       // user detail which is present inside the token 
  //       req.user = user;
  //     });
  //     const sqlQuery = "SELECT * FROM task ";
  //     const allUser = await con.query(sqlQuery, (err, result) => {
  //       if (err) {
  //         return res.json({ status: 400, response: err.sqlMessage })
  //       }
  //       return res.json({ status: 200, response: result })
  //     })

  //   } catch (err) {
  //     res.json({ status: 400, response: err.message });
  //   }
  // },

  singleUserTask: async (req, res) => {
    try {
      const token = req.header("token");

      await jwt.verify(token, process.env.JWT_TOKEN, (err, user) => {
        if (err) {
          return createError(401, "token is not verified")
        }
        // user detail which is present inside the token 
        req.user = user;
      });
      const email = req.user.email;
      const sqlQuery = "SELECT * task WHERE user = ? ";
      await con.query(sqlQuery, email, (err, result) => {
        if (err) {
          return res.json({ Error: err.sqlMessage })
        }
        return res.json({ status: 200, response: result })
      })
    } catch (err) {
      res.json({ error: err.message });
    }
  },
  updateById: async (req, res) => {
    try {
      const token = req.headers("token");
      await jwt.verify(token, process.env.JWT_TOKEN, (err, user) => {
        if (err) {
          return createError(401, "token is not verified")
        }
        // user detail which is present inside the token 
        req.user = user;
      });
      const { title, due_date } = req.body;
      const email = req.user.email
      const data = { title, due_date, attachment, user };

      const sqlQuery = "UPDATE user SET ? WHERE email = ?  ";
      await con.query(sqlQuery, [data, email], (err, result) => {
        if (err) {
          return res.json({ Error: err.sqlMessage })
        }
        return res.json({ status: 200, response: result })
      })

    } catch (err) {
      res.send({ err: err.message });
    }
  },
  /*
 
 Delete task by task ID
 
 */
  deleteTaskById: async (req, res) => {
    try {
      const token = req.headers("token");
      await jwt.verify(token, process.env.JWT_TOKEN, (err, user) => {
        if (err) {
          return createError(401, "token is not verified")
        }
        // user detail which is present inside the token 
        req.user = user;
      });
      const email = req.user.email
      const sqlQuery = "DELETE FROM task WHERE id = ? ";
      await con.query(sqlQuery, email, (err, result) => {
        if (err) {
          return res.json({ Error: err.sqlMessage })
        }
        return res.json({ Status: 200, Message: "Task deleted successfully", result })
      })

    } catch (err) {
      res.send({ err: err.message });
    }
  },
};